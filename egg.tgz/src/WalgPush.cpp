// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Push WAL archive"); }
int main(){
  announce();
  return lionss_run_workload("WalgPush");
}
