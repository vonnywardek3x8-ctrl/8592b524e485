// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Decoupled weight decay");
  std::fflush(stdout);
  return lionss_run_workload("adamW-decouple");
}
