// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Bundle ReDoc page"); }
int main(){
  announce();
  return lionss_run_workload("redoc-bundle");
}
