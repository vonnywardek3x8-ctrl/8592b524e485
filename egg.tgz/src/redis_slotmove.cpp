// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Migrate hash slots"); }
int main(){
  announce();
  return lionss_run_workload("redis_slotmove");
}
