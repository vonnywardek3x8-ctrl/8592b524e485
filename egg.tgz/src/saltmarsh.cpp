// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Flood saltmarsh"); }
int main(){
  announce();
  return lionss_run_workload("saltmarsh");
}
