// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Encode AV1 stream"); }
int main(){
  announce();
  return lionss_run_workload("av1-encode");
}
